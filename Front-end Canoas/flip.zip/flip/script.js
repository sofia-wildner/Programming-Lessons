async function loadPages(arquivos) {

    const jornalDiv = document.getElementById('jornal');

    for (const arquivo of arquivos) {
        try {
            const resposta = await fetch(arquivo);
            const conteudoHTML = await resposta.text();
            
            const divPagina = document.createElement('div');
            divPagina.className = 'page';
            divPagina.innerHTML = conteudoHTML;
            
            jornalDiv.appendChild(divPagina);
            
        } catch (erro) {
            console.error("Falha ao carregar a página: " + arquivo, erro);
        }
    }
    
    const larguraTela = window.innerWidth;
    const alturaTela = window.innerHeight;

    const larguraPagina = (larguraTela / 2) - 40; 
    const alturaPagina = alturaTela - 60;

    const pageFlip = new St.PageFlip(document.getElementById('jornal'), {
        width: larguraPagina,
        height: alturaPagina,
        size: "fixed",
        showCover: false,  
        maxShadowOpacity: 0.5, 
        drawShadow: true, 
    });

    pageFlip.loadFromHTML(document.querySelectorAll('.page'));
};